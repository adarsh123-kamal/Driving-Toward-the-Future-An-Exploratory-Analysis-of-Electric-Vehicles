import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")

# Load the dataset
file_path = r"C:\Users\adars\OneDrive\Desktop\lpu\sem4\INT375  DATA SCIENCE TOOLBOX PYTHON PROGRAMMING\project\Electric_Vehicle_Population_Data (1).csv"
df = pd.read_csv(file_path)


# Shape of dataset
print("Dataset Shape:", df.shape)

# Data types
print("\nData Types:\n", df.dtypes)

# First 5 rows
print("\nFirst 5 Rows:\n", df.head())

# --------------------
# Missing Values
# --------------------
a=df.isnull().sum()
print("\nMissing Values:\n", a)
b=df.isnull().sum().sum()
print("\nTotal Missing values:\n",b)

# Fill missing categorical columns with mode
for col in df.select_dtypes(include='object').columns:
    df[col].fillna(df[col].mode()[0], inplace=True)

# Fill missing numerical columns with median
for col in df.select_dtypes(include='number').columns:
    df[col].fillna(df[col].median(), inplace=True)

print("Missing values after filling:\n", df.isnull().sum())

# --------------------
# Basic Statistics
# --------------------
b=df.describe()
print("\nBasic Statistics:\n", b)


# Top 10 states with most EVs
state_counts = df['State'].value_counts().head(10)
print("\nTop 10 States:\n", state_counts)
#visualization
plt.figure(figsize=(10,6))
sns.barplot(x=state_counts.values,y=state_counts.index,hue=state_counts.index,palette="viridis",legend=False)
plt.title('Top 10 States with Most Electric Vehicles')
plt.xlabel('Number of Vehicles')
plt.ylabel('State')
for i, v in enumerate(state_counts.values):
    plt.text(v + 50, i, str(v), color='black', va='center', fontweight='bold')
plt.tight_layout()
plt.show()


# Top 10 cities
city_counts = df['City'].value_counts().head(10)
print("\nTop 10 Cities:\n", city_counts)
#visualization
plt.figure(figsize=(10,6))
sns.barplot(x=city_counts.values,y=city_counts.index,hue=city_counts.index,palette="magma",legend=False)
plt.title('Top 10 Cities with Most Electric Vehicles')
plt.xlabel('Number of Vehicles')
plt.ylabel('City')
for i, v in enumerate(city_counts.values):
    plt.text(v + 50, i, str(v), color='black', va='center', fontweight='bold')
plt.tight_layout()
plt.show()
print()


# Top 10 EV makes
make_counts = df['Make'].value_counts().head(10)
print("\nTop 10 Makes:\n", make_counts)
#visualization
plt.figure(figsize=(10,6))
sns.barplot(x=make_counts.values,y=make_counts.index,hue=make_counts.index,palette="coolwarm",legend=False)
plt.title('Top 10 EV Makes')
plt.xlabel('Number of Vehicles')
plt.ylabel('Make')
for i, v in enumerate(make_counts.values):
    plt.text(v + 50, i, str(v), color='black', va='center', fontweight='bold')
plt.tight_layout()
plt.show()
print()


# Top 10 EV models
model_counts = df['Model'].value_counts().head(10)
print("\nTop 10 Models:\n", model_counts)
#visualization
plt.figure(figsize=(10,6))
sns.barplot(x=model_counts.values,y=model_counts.index,hue=model_counts.index,palette="cubehelix",legend=False)
plt.title('Top 10 EV Models')
plt.xlabel('Number of Vehicles')
plt.ylabel('Model')
for i, v in enumerate(model_counts.values):
    plt.text(v + 50, i, str(v), color='black', va='center', fontweight='bold')
plt.tight_layout()
plt.show()
print()


# Model year distribution
year_counts = df['Model Year'].value_counts().sort_index()
plt.figure(figsize=(12,6))
sns.lineplot(x=year_counts.index, y=year_counts.values, marker='o')
plt.title('Electric Vehicles Distribution by Model Year')
plt.xlabel('Model Year')
plt.ylabel('Number of Vehicles')
plt.xticks(rotation=45)
plt.grid()
plt.show()



# Electric Vehicle Types Distribution
type_counts = df['Electric Vehicle Type'].value_counts()
plt.figure(figsize=(10,6))
sns.barplot(x=type_counts.index,y=type_counts.values,hue=type_counts.index,palette="pastel",legend=False)
plt.title('Electric Vehicle Types Distribution')
plt.xlabel('Vehicle Type')
plt.ylabel('Number of Vehicles')
for i, v in enumerate(make_counts.values):
    plt.text(v + 50, i, str(v), color='black', va='center', fontweight='bold')
plt.tight_layout()
plt.xticks(rotation=45)
plt.show()



# Distribution of Electric Range
plt.figure(figsize=(10,6))
sns.histplot(df['Electric Range'].dropna(), bins=30, kde=True, color='skyblue')
plt.title('Distribution of Electric Range')
plt.xlabel('Electric Range (miles)')
plt.ylabel('Number of Vehicles')
plt.grid()
plt.show()


# Electric range vs number of vehicles (binned)
df['Range Category'] = pd.cut(df['Electric Range'], bins=[0, 50, 100, 150, 200, 250, 300, 400, 500])
range_counts = df['Range Category'].value_counts().sort_index()
plt.figure(figsize=(10,6))
sns.barplot(x=range_counts.index.astype(str),y=range_counts.values,hue=range_counts.index.astype(str),palette="Set2",legend=False)
plt.title('Electric Vehicles by Range Categories')
plt.xlabel('Range Category (miles)')
plt.ylabel('Number of Vehicles')
for i, v in enumerate(make_counts.values):
    plt.text(v + 50, i, str(v), color='black', va='center', fontweight='bold')
plt.tight_layout()
plt.xticks(rotation=45)
plt.show()



# Explore BEV vs PHEV counts
if 'Electric Vehicle Type' in df.columns:
    bev_phev = df['Electric Vehicle Type'].value_counts()
    plt.figure(figsize=(6, 6))
    plt.pie(bev_phev.values, labels=bev_phev.index, autopct='%1.1f%%', startangle=90, colors=sns.color_palette('Set3'))
    plt.title('BEV vs PHEV Distribution')
    plt.axis('equal')
    plt.show()


# CAFV Eligibility Distribution
plt.figure(figsize=(8,6))
sns.countplot(data=df, x='Clean Alternative Fuel Vehicle (CAFV) Eligibility',hue='Clean Alternative Fuel Vehicle (CAFV) Eligibility', palette="Set3")
plt.title('CAFV Eligibility Distribution')
plt.xlabel('CAFV Eligibility')
plt.ylabel('Count')
plt.xticks(rotation=45)
plt.show()


# Correlation Heatmap
plt.figure(figsize=(12,8))
numeric_cols = df.select_dtypes(include='number')  # Only numeric columns
corr = numeric_cols.corr()

sns.heatmap(corr, annot=True, cmap='coolwarm', fmt=".2f", linewidths=0.5)
plt.title('Correlation Heatmap')
plt.show()



#PERFORMING Z-TEST BETWEEN TESLA AND NISSAN MODEL YEARS

# Get Tesla and Nissan Model Years
tesla = df[df['Make'] == 'TESLA']['Model Year'].dropna()
nissan = df[df['Make'] == 'NISSAN']['Model Year'].dropna()

# Tesla stats
mean_tesla = tesla.mean()
std_tesla = tesla.std(ddof=1)
n_tesla = len(tesla)

# Nissan stats
mean_nissan = nissan.mean()
std_nissan = nissan.std(ddof=1)
n_nissan = len(nissan)

# Calculating Z-statistic manually
z = (mean_tesla - mean_nissan) / np.sqrt((std_tesla**2 / n_tesla) + (std_nissan**2 / n_nissan))

print(f"Tesla Mean: {mean_tesla}")
print(f"Nissan Mean: {mean_nissan}")
print(f"Z-statistic: {z}")

# Manual decision based on z
if abs(z) > 1.96:
    print("Result: Significant difference between Tesla and Nissan model years.")
else:
    print("Result: No significant difference between Tesla and Nissan model years.")


#DETECTING AND CORRECTING OUTLIERS
# --------------------
# Detecting Outliers
# --------------------
def detect_outliers(series):
    Q1 = series.quantile(0.25)
    Q3 = series.quantile(0.75)
    IQR = Q3 - Q1
    lower_limit = Q1 - 1.5 * IQR
    upper_limit = Q3 + 1.5 * IQR
    outliers = series[(series < lower_limit) | (series > upper_limit)]
    return outliers

# Example: Detect outliers in a numerical column
num_cols = df.select_dtypes(include='number').columns
for col in num_cols:
    outliers = detect_outliers(df[col])
    print(f"\nNumber of outliers in '{col}': {len(outliers)}")

#correcting outliers
def cap_outliers(series):
    Q1 = series.quantile(0.25)
    Q3 = series.quantile(0.75)
    IQR = Q3 - Q1
    lower_limit = Q1 - 1.5 * IQR
    upper_limit = Q3 + 1.5 * IQR
    return series.clip(lower=lower_limit, upper=upper_limit)

# Applying it to numerical columns
num_cols = df.select_dtypes(include='number').columns
for col in num_cols:
    df[col] = cap_outliers(df[col])

print("\nOutliers fixed successfully")

print("Outliers After fixing:")
for col in num_cols:
    outliers = detect_outliers(df[col])
    print(f"'{col}': {len(outliers)} outliers")

